import type { DimensionId } from "../types/churn";

interface DimensionContent {
  riskExplanation: string;
  hiddenRiskReason: string;
  strengthStatement: string;
  priorityAction: string;
  plan30: string;
  plan90: string;
  measure: string;
}

export const DIMENSION_CONTENT: Record<DimensionId, DimensionContent> = {
  "churn-visibility": {
    riskExplanation:
      "Churn is not being measured with enough precision to manage it. Decisions about retention are currently based on impressions rather than a defensible number.",
    hiddenRiskReason:
      "The business may believe it understands churn because a top-line number exists, without realizing that number obscures how and where revenue is actually leaving.",
    strengthStatement: "Churn is measured precisely enough to be trusted as a management metric.",
    priorityAction: "Instrument churn measurement: define gross vs. net, voluntary vs. involuntary, at a monthly cadence.",
    plan30: "Stand up a single source of truth for churn rate, reconciled monthly between billing and CRM data.",
    plan90: "Automate a recurring retention report reviewed on a fixed cadence, not produced ad hoc.",
    measure: "Gross churn rate, net revenue retention, and voluntary vs. involuntary split, tracked monthly.",
  },
  "churn-pattern": {
    riskExplanation:
      "Churn is being treated as one undifferentiated problem, when it almost certainly concentrates in specific segments, cohorts, or causes that could be addressed directly.",
    hiddenRiskReason:
      "Without cohort-level analysis, an improving top-line churn number can hide a deteriorating high-value segment underneath it.",
    strengthStatement: "Churn is understood at the segment and cause level, not just in aggregate.",
    priorityAction: "Segment churn by plan, cohort, acquisition channel, and stated reason to find where it concentrates.",
    plan30: "Pull the last two quarters of cancellations and tag each with a reason and segment, even retroactively.",
    plan90: "Build a standing cohort-retention view so concentration is visible before it becomes a trend.",
    measure: "Churn rate by cohort, plan tier, and exit reason category.",
  },
  "onboarding-ttv": {
    riskExplanation:
      "Customers are not reliably reaching first value quickly. This is one of the highest-leverage points in the lifecycle — early friction here compounds into churn much later.",
    hiddenRiskReason:
      "Onboarding gaps often get blamed on 'product fit' months later, when the real failure happened in the first two weeks and was never diagnosed as such.",
    strengthStatement: "Onboarding reliably and quickly gets customers to their first meaningful outcome.",
    priorityAction: "Define and instrument a concrete 'first value' milestone, then measure time-to-reach it for every new customer.",
    plan30: "Map the current onboarding path and identify the single biggest drop-off point.",
    plan90: "Rebuild onboarding around one measurable milestone, with owner accountability for time-to-value.",
    measure: "Median time-to-first-value and % of customers who reach it within your target window.",
  },
  adoption: {
    riskExplanation:
      "A meaningful share of customers are not using the core value they're paying for. Low adoption is the leading indicator that almost always precedes cancellation.",
    hiddenRiskReason:
      "Revenue can look stable while usage quietly erodes underneath it — by the time adoption shows up as churn, the customer has usually already decided to leave.",
    strengthStatement: "Customers consistently use the core value they're paying for.",
    priorityAction: "Define the 2-3 usage behaviors that correlate most with renewal, and monitor them per account.",
    plan30: "Identify the accounts with the lowest usage in the last 30 days and understand why.",
    plan90: "Build a lightweight adoption dashboard visible to whoever owns each account relationship.",
    measure: "Active usage rate against the core value proposition, tracked per account per month.",
  },
  "health-signals": {
    riskExplanation:
      "Warning signs of churn are not visible before the customer has already decided to leave. This turns every cancellation into a surprise instead of a manageable event.",
    hiddenRiskReason:
      "Teams often feel confident because support tickets are handled well — but support tickets are a lagging signal, not an early one. Silence, not complaints, is usually the real warning sign.",
    strengthStatement: "Leading indicators of churn risk are visible well before a cancellation.",
    priorityAction: "Define 3-5 concrete health signals (usage drop, stakeholder change, sentiment, payment risk) and monitor them systematically.",
    plan30: "List every signal that, in hindsight, appeared before your last 10 cancellations.",
    plan90: "Formalize those signals into a lightweight health score reviewed on a fixed cadence.",
    measure: "% of at-risk accounts flagged more than 30 days before cancellation or renewal decision.",
  },
  intervention: {
    riskExplanation:
      "Even where risk is visible, there is no consistent process for acting on it before the customer leaves. Visibility without intervention still produces churn.",
    hiddenRiskReason:
      "It's easy to assume 'someone is handling it' when retention has no single owner — in practice, ambiguous ownership means at-risk accounts are handled inconsistently or not at all.",
    strengthStatement: "At-risk accounts are engaged proactively, before the decision to leave is final.",
    priorityAction: "Assign explicit ownership for retention intervention and define the trigger that starts it.",
    plan30: "Name an owner for retention intervention and define one trigger that requires action within 48 hours.",
    plan90: "Build documented playbooks for the 3 most common at-risk scenarios you see.",
    measure: "% of flagged at-risk accounts with a documented intervention within 7 days.",
  },
  renewal: {
    riskExplanation:
      "Renewal is currently closer to a deadline than a managed revenue event, which leaves recurring revenue exposed to last-minute surprises.",
    hiddenRiskReason:
      "Automatic renewal can look like a strength (low friction) while actually hiding disengaged customers who simply haven't cancelled yet.",
    strengthStatement: "Renewal is actively managed as a revenue event, well ahead of the decision point.",
    priorityAction: "Build a renewal engagement sequence that starts well before the renewal date, not at it.",
    plan30: "List every account renewing in the next 60 days and confirm engagement status for each.",
    plan90: "Install a standard renewal cadence (e.g. 90/60/30-day check-ins) tied to account ownership.",
    measure: "Renewal engagement rate: % of upcoming renewals with a documented touchpoint before the renewal date.",
  },
  "value-realization": {
    riskExplanation:
      "The business cannot currently demonstrate, with evidence, that customers are receiving the outcome they were promised. Unproven value is fragile value.",
    hiddenRiskReason:
      "A customer who privately doubts the ROI of what they bought rarely says so directly — they simply don't renew, and the reason gets recorded as something else.",
    strengthStatement: "The delivered outcome is provable, not just assumed.",
    priorityAction: "Define the one outcome metric that proves value, and start reporting it back to customers directly.",
    plan30: "Identify the single metric that best proves your value proposition and confirm you can measure it per customer.",
    plan90: "Build a recurring value-recap touchpoint (report, review, or summary) delivered to every customer.",
    measure: "% of customers with a documented, measurable outcome tied to your product/service in the last quarter.",
  },
  "experience-alignment": {
    riskExplanation:
      "There is a gap between what is promised at the point of sale and what is actually experienced afterward. This kind of mismatch produces churn that looks like a product problem but is actually an expectations problem.",
    hiddenRiskReason:
      "Overpromising is often a sales or marketing success in the short term and a retention liability a few months later — the two teams rarely see the connection.",
    strengthStatement: "What is promised at the sale consistently matches what is delivered.",
    priorityAction: "Audit the current sales/marketing promise against the actual first-90-day experience.",
    plan30: "Compare your sales pitch or marketing claims directly against your onboarding reality.",
    plan90: "Close the largest gap found, and add a review step before promises change going forward.",
    measure: "Rate of stated cancellation reasons tied to 'expected something different'.",
  },
  "economics-awareness": {
    riskExplanation:
      "Leadership does not have a clear, quantified view of what churn actually costs — which makes it very difficult to justify investment in fixing it.",
    hiddenRiskReason:
      "Without a dollar figure attached to churn, retention initiatives compete poorly for budget and attention against growth initiatives with more visible ROI.",
    strengthStatement: "The financial cost of churn is quantified and used to guide investment decisions.",
    priorityAction: "Calculate a simple, defensible revenue-at-risk figure and put it in front of leadership.",
    plan30: "Calculate current MRR, churn rate, and resulting monthly revenue at risk using available data.",
    plan90: "Attach a revenue-preserved target to any retention initiative, and report against it quarterly.",
    measure: "Monthly and annualized revenue at risk, tracked as a standing leadership metric.",
  },
};
