import type { AnswerMap, RevenueFigure, RevenueImpact } from "../types/churn";

function fig(value: number | null, source: RevenueFigure["source"]): RevenueFigure {
  return { value, source };
}

const num = (v: unknown): number | null => {
  if (v === undefined || v === null || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v));
  return Number.isFinite(n) ? n : null;
};

/**
 * Deterministic revenue-exposure calculator. Every output is traceable to
 * either a direct user input, a formula applied to user inputs, or a clearly
 * labeled scenario assumption. Nothing is fabricated: if inputs are missing,
 * the corresponding figure is null and the UI must show "insufficient data".
 */
export function computeRevenueImpact(answers: AnswerMap): RevenueImpact {
  const customerCount = num(answers["customer_count"]);
  const avgValue = num(answers["avg_customer_value"]);
  const mrrDirect = num(answers["mrr_value"]);
  const churnRatePct = num(answers["monthly_churn_rate"]);

  const derivedMrr = customerCount !== null && avgValue !== null ? customerCount * avgValue : null;
  const mrrValue = mrrDirect ?? derivedMrr;
  const mrr = fig(mrrValue, mrrDirect !== null ? "user" : derivedMrr !== null ? "calculated" : "user");

  const monthlyChurnRatePct = fig(churnRatePct, "user");

  const customersLostMonthly =
    customerCount !== null && churnRatePct !== null
      ? fig(Math.round(customerCount * (churnRatePct / 100)), "calculated")
      : fig(null, "calculated");

  const monthlyRevenueAtRisk =
    mrrValue !== null && churnRatePct !== null
      ? fig(mrrValue * (churnRatePct / 100), "calculated")
      : fig(null, "calculated");

  const annualizedRevenueAtRisk =
    monthlyRevenueAtRisk.value !== null
      ? fig(monthlyRevenueAtRisk.value * 12, "calculated")
      : fig(null, "calculated");

  const approximateLtv =
    avgValue !== null && churnRatePct !== null && churnRatePct > 0
      ? fig(avgValue / (churnRatePct / 100), "estimated")
      : fig(null, "estimated");

  const scenarios =
    annualizedRevenueAtRisk.value !== null
      ? [0.1, 0.25, 0.4].map((reductionPct) => ({
          reductionPct,
          annualRevenuePreserved: Math.round(annualizedRevenueAtRisk.value! * reductionPct),
        }))
      : [];

  const missingInputs: string[] = [];
  if (mrrValue === null) missingInputs.push("Monthly recurring revenue (or customer count + average value)");
  if (churnRatePct === null) missingInputs.push("Monthly churn rate");

  return {
    currencySymbol: "$",
    mrr,
    monthlyChurnRatePct,
    customersLostMonthly,
    monthlyRevenueAtRisk,
    annualizedRevenueAtRisk,
    approximateLtv,
    scenarios,
    hasSufficientData: mrrValue !== null && churnRatePct !== null,
    missingInputs,
  };
}
