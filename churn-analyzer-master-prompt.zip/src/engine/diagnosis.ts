import { DIMENSION_MAP } from "../data/dimensions";
import { QUESTION_MAP } from "../data/questions";
import { DIMENSION_CONTENT } from "./contentTemplates";
import { computeCompletion, computeDimensionResults, computeLifecycleResults, computeOverallHealth } from "./scoring";
import { computeRevenueImpact } from "./revenue";
import type { AnswerMap, DiagnosisResult, DimensionResult } from "../types/churn";

const REASON_LABELS: Record<string, string> = {
  price: "price or perceived value mismatch",
  onboarding: "a weak onboarding experience",
  adoption: "customers never fully adopting the product/service",
  gap: "a gap between the product/service and the customer's actual need",
  competitor: "customers switching to a competitor",
  support: "poor support or service experience",
  budget: "budget cuts or company changes on the customer's side",
  billing: "payment or billing failures",
};

function buildRootCause(answers: AnswerMap, dimensions: DimensionResult[]) {
  const reasonsRaw = answers["churn_reasons_detail"];
  const reasons = Array.isArray(reasonsRaw) ? reasonsRaw : [];

  if (reasons.length > 0) {
    const labels = reasons.map((r) => REASON_LABELS[r] ?? r);
    const headline =
      labels.length === 1
        ? `Reported root cause: ${labels[0]}.`
        : `Reported root causes concentrate around ${labels.slice(0, -1).join(", ")} and ${labels[labels.length - 1]}.`;
    return {
      headline,
      explanation:
        "This is drawn directly from customer-reported exit reasons rather than inferred from process gaps — treat it as the primary signal, and use the diagnostic dimensions below to explain why it keeps happening structurally.",
      evidenceSource: "reported" as const,
    };
  }

  // Fall back to inference: weakest dimension, weighted by revenue relevance.
  const sorted = [...dimensions].sort((a, b) => {
    const sevA = (100 - a.score) * DIMENSION_MAP[a.id].weight;
    const sevB = (100 - b.score) * DIMENSION_MAP[b.id].weight;
    return sevB - sevA;
  });
  const weakest = sorted[0];
  const def = DIMENSION_MAP[weakest.id];
  return {
    headline: `Inferred root cause: structural weakness in ${def.name.toLowerCase()}.`,
    explanation: `No customer-reported exit reasons were available, so this is inferred from the diagnostic pattern rather than direct customer evidence. ${DIMENSION_CONTENT[weakest.id].riskExplanation}`,
    evidenceSource: "inferred" as const,
  };
}

function buildHiddenRisk(dimensions: DimensionResult[], topRiskIds: Set<string>) {
  const candidates = dimensions.filter((d) => !topRiskIds.has(d.id));
  if (candidates.length === 0) return null;

  // Prefer a dimension with heavy "unknown" evidence — a genuine blind spot —
  // over one that's simply mid-scoring.
  const blindSpots = candidates
    .filter((d) => d.answeredCount > 0 && d.unknownCount / d.answeredCount >= 0.34)
    .sort((a, b) => b.unknownCount / Math.max(b.answeredCount, 1) - a.unknownCount / Math.max(a.answeredCount, 1));

  const chosen = blindSpots[0] ?? [...candidates].sort((a, b) => a.score - b.score)[0];
  if (!chosen) return null;

  const def = DIMENSION_MAP[chosen.id];
  return {
    dimension: chosen,
    def,
    reason: DIMENSION_CONTENT[chosen.id].hiddenRiskReason,
  };
}

function buildEarlyWarningGap(dimensions: DimensionResult[]): string {
  const healthDim = dimensions.find((d) => d.id === "health-signals");
  if (!healthDim || healthDim.driverQuestions.length === 0) {
    return "Early-warning coverage could not be assessed — no health-signal questions were answered.";
  }
  const weakest = [...healthDim.driverQuestions].sort((a, b) => a.maturity - b.maturity)[0];
  const q = QUESTION_MAP[weakest.questionId];
  if (!q) return "Early-warning coverage has an unaddressed gap.";
  if (weakest.maturity >= 2.5) {
    return "Early-warning coverage is comparatively strong — signals are being captured before cancellation in most cases.";
  }
  return `The clearest early-warning gap: "${q.prompt}" — currently answered as "${weakest.selectedLabel}". This is the signal most likely to let an at-risk customer disappear unnoticed.`;
}

function buildConfidenceNote(answers: AnswerMap): string | null {
  const count = answers["customer_count"];
  const n = typeof count === "number" ? count : parseFloat(String(count ?? ""));
  if (Number.isFinite(n) && n > 0 && n < 30) {
    return "Customer volume is small enough that percentages here are directional, not statistically precise. Treat this as a structural diagnosis rather than a statistical one.";
  }
  return null;
}

export function runDiagnosis(answers: AnswerMap): DiagnosisResult {
  const dimensions = computeDimensionResults(answers);
  const overall = computeOverallHealth(dimensions);
  const lifecycle = computeLifecycleResults(dimensions);
  const revenue = computeRevenueImpact(answers);

  const ranked = [...dimensions]
    .map((d) => ({
      dimension: d,
      def: DIMENSION_MAP[d.id],
      severityScore: (100 - d.score) * DIMENSION_MAP[d.id].weight,
    }))
    .sort((a, b) => b.severityScore - a.severityScore);

  const topRisks = ranked.slice(0, 3);
  const topRiskIds = new Set(topRisks.map((r) => r.dimension.id));

  const hiddenRisk = buildHiddenRisk(dimensions, topRiskIds);

  const strongest = [...dimensions].sort((a, b) => b.score - a.score)[0];
  const strongestAsset = { dimension: strongest, def: DIMENSION_MAP[strongest.id] };

  const earlyWarningGap = buildEarlyWarningGap(dimensions);
  const rootCause = buildRootCause(answers, dimensions);

  const priorityActions = topRisks.map((r) => DIMENSION_CONTENT[r.dimension.id].priorityAction);
  const plan30 = topRisks.map((r) => DIMENSION_CONTENT[r.dimension.id].plan30);
  const plan90 = topRisks.map((r) => DIMENSION_CONTENT[r.dimension.id].plan90);
  const whatToMeasureNext = [...topRisks, { dimension: strongest, def: strongestAsset.def, severityScore: 0 }]
    .slice(0, 4)
    .map((r) => DIMENSION_CONTENT[r.dimension.id].measure);

  const confidenceNote = buildConfidenceNote(answers);

  return {
    overall,
    dimensions,
    lifecycle,
    revenue,
    topRisks,
    hiddenRisk,
    strongestAsset,
    earlyWarningGap,
    rootCause,
    priorityActions,
    plan30,
    plan90,
    whatToMeasureNext,
    confidenceNote,
  };
}

export { computeCompletion };
