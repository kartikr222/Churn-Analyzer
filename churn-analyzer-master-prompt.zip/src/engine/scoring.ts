import { ALL_QUESTIONS, QUESTION_MAP } from "../data/questions";
import { DIMENSIONS, DIMENSION_MAP } from "../data/dimensions";
import { LIFECYCLE_STAGES } from "../data/dimensions";
import type {
  AnswerMap,
  BaselineContext,
  DimensionId,
  DimensionResult,
  HealthBand,
  LifecycleStageResult,
  OverallHealth,
  RiskLevel,
} from "../types/churn";

export function getBaselineContext(answers: AnswerMap): BaselineContext {
  return {
    businessModel: answers["business_model"] as string | undefined,
    customerType: answers["customer_type"] as string | undefined,
    cycleLabel: answers["renewal_cycle"] as string | undefined,
  };
}

/** Is a question currently applicable given branching rules + baseline context? */
export function isQuestionVisible(questionId: string, answers: AnswerMap): boolean {
  const q = QUESTION_MAP[questionId];
  if (!q) return false;
  if (!q.showIf) return true;
  return q.showIf(answers, getBaselineContext(answers));
}

function scoreToRisk(score: number): RiskLevel {
  if (score < 35) return "critical";
  if (score < 55) return "high";
  if (score < 75) return "moderate";
  return "low";
}

/** Computes a 0-100 score + evidence trail for every scored dimension. */
export function computeDimensionResults(answers: AnswerMap): DimensionResult[] {
  return DIMENSIONS.map((dim) => {
    const relevantQuestions = ALL_QUESTIONS.filter(
      (q) => q.dimensionIds.includes(dim.id) && q.options && isQuestionVisible(q.id, answers)
    );

    const driverQuestions: DimensionResult["driverQuestions"] = [];
    let maturitySum = 0;
    let maturityCount = 0;
    let unknownCount = 0;

    for (const q of relevantQuestions) {
      const raw = answers[q.id];
      if (raw === undefined || (Array.isArray(raw) && raw.length === 0)) continue;

      if (q.type === "multi" && Array.isArray(raw)) {
        // Multi-select: average maturity across selected options counts as evidence
        // but does not by itself prove strength — it's capped as informative context.
        const opts = raw
          .map((id) => q.options?.find((o) => o.id === id))
          .filter(Boolean) as NonNullable<typeof q.options>;
        if (opts.length > 0) {
          const avg = opts.reduce((s, o) => s + o.maturity, 0) / opts.length;
          maturitySum += avg;
          maturityCount += 1;
          driverQuestions.push({
            questionId: q.id,
            prompt: q.prompt,
            selectedLabel: opts.map((o) => o.label).join(", "),
            maturity: avg,
            isUnknown: false,
          });
        }
        continue;
      }

      const opt = q.options?.find((o) => o.id === raw);
      if (!opt) continue;
      maturitySum += opt.maturity;
      maturityCount += 1;
      if (opt.isUnknown) unknownCount += 1;
      driverQuestions.push({
        questionId: q.id,
        prompt: q.prompt,
        selectedLabel: opt.label,
        maturity: opt.maturity,
        isUnknown: !!opt.isUnknown,
      });
    }

    const totalCount = relevantQuestions.length;
    const answeredCount = maturityCount;
    const avgMaturity = maturityCount > 0 ? maturitySum / maturityCount : null;
    let score = avgMaturity !== null ? Math.round((avgMaturity / 3) * 100) : 0;

    // Visibility gap penalty: if the majority of driver answers for this
    // dimension are explicit "unknown" admissions, cap the score — you cannot
    // be "healthy" on a dimension you cannot see.
    if (answeredCount > 0 && unknownCount / answeredCount >= 0.5) {
      score = Math.min(score, 34);
    }

    let confidence: DimensionResult["confidence"] = "known";
    if (answeredCount === 0) confidence = "unknown";
    else if (unknownCount / Math.max(answeredCount, 1) >= 0.34) confidence = "estimated";

    return {
      id: dim.id,
      score,
      risk: scoreToRisk(score),
      answeredCount,
      totalCount,
      unknownCount,
      confidence,
      driverQuestions,
    };
  });
}

const HEALTH_BANDS: { min: number; band: HealthBand; label: string }[] = [
  { min: 80, band: "advantage", label: "Retention Advantage" },
  { min: 65, band: "stable", label: "Retention Stable" },
  { min: 45, band: "exposed", label: "Retention Exposed" },
  { min: 25, band: "leaking", label: "Retention Leaking" },
  { min: 0, band: "critical", label: "Retention Critical" },
];

export function computeOverallHealth(dimensionResults: DimensionResult[]): OverallHealth {
  const weightedSum = dimensionResults.reduce((sum, r) => {
    const def = DIMENSION_MAP[r.id];
    return sum + r.score * def.weight;
  }, 0);
  const totalWeight = dimensionResults.reduce((sum, r) => sum + DIMENSION_MAP[r.id].weight, 0);
  const score = Math.round(weightedSum / totalWeight);
  const bandInfo = HEALTH_BANDS.find((b) => score >= b.min) ?? HEALTH_BANDS[HEALTH_BANDS.length - 1];

  const narratives: Record<HealthBand, string> = {
    advantage:
      "Retention behaves like a system here, not an accident. Visibility, intervention, and renewal management are all functioning — the priority now is defending this position as the business scales.",
    stable:
      "The retention system is functional but uneven. Some stages of the customer lifecycle are well managed while others rely on informal judgment. Revenue is not obviously leaking, but it isn't fully protected either.",
    exposed:
      "Retention is being managed reactively. Several lifecycle stages lack visibility or ownership, which means revenue is likely leaking in ways that haven't been quantified yet.",
    leaking:
      "Multiple structural gaps compound each other — weak early visibility, inconsistent onboarding, and late intervention are very likely producing preventable churn today.",
    critical:
      "The business currently has limited ability to see, predict, or intervene on churn before it happens. At this stage, churn is closer to a surprise than a managed outcome.",
  };

  return { score, band: bandInfo.band, label: bandInfo.label, narrative: narratives[bandInfo.band] };
}

export function computeLifecycleResults(dimensionResults: DimensionResult[]): LifecycleStageResult[] {
  const byId: Record<DimensionId, DimensionResult> = Object.fromEntries(
    dimensionResults.map((r) => [r.id, r])
  ) as Record<DimensionId, DimensionResult>;

  return LIFECYCLE_STAGES.map((stage) => {
    const dims = DIMENSIONS.filter((d) => d.lifecycleStage === stage.id);
    const scores = dims.map((d) => byId[d.id]?.score ?? 0);
    const score = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
    return {
      id: stage.id,
      label: stage.label,
      score,
      risk: scoreToRisk(score),
      dimensionIds: dims.map((d) => d.id),
    };
  });
}

/** % of all *currently visible* questions that have been answered. */
export function computeCompletion(answers: AnswerMap): { answered: number; total: number; pct: number } {
  const visible = ALL_QUESTIONS.filter((q) => isQuestionVisible(q.id, answers));
  const answered = visible.filter((q) => {
    const v = answers[q.id];
    return v !== undefined && !(Array.isArray(v) && v.length === 0) && v !== "";
  }).length;
  return { answered, total: visible.length, pct: visible.length ? Math.round((answered / visible.length) * 100) : 0 };
}
