import { useCallback, useEffect, useMemo, useState } from "react";
import type { AnswerMap, AnswerValue } from "../types/churn";
import { CHAPTERS } from "../data/questions";
import { computeCompletion, isQuestionVisible } from "../engine/scoring";
import { runDiagnosis } from "../engine/diagnosis";

export type ScreenState = "intro" | "wizard" | "report";

const STORAGE_KEY = "kc-churn-analyzer-v1";

interface Persisted {
  screen: ScreenState;
  chapterIndex: number;
  answers: AnswerMap;
}

function loadPersisted(): Persisted | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Persisted;
  } catch {
    return null;
  }
}

export function useChurnDiagnostic() {
  const initial = typeof window !== "undefined" ? loadPersisted() : null;

  const [screen, setScreen] = useState<ScreenState>(initial?.screen ?? "intro");
  const [chapterIndex, setChapterIndex] = useState(initial?.chapterIndex ?? 0);
  const [answers, setAnswers] = useState<AnswerMap>(initial?.answers ?? {});

  useEffect(() => {
    const payload: Persisted = { screen, chapterIndex, answers };
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch {
      /* storage unavailable — non-fatal */
    }
  }, [screen, chapterIndex, answers]);

  const setAnswer = useCallback((questionId: string, value: AnswerValue) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  }, []);

  const chapter = CHAPTERS[chapterIndex];

  const chapterQuestions = useMemo(
    () => (chapter ? chapter.questions.filter((q) => isQuestionVisible(q.id, answers)) : []),
    [chapter, answers]
  );

  const chapterComplete = useMemo(
    () =>
      chapterQuestions.every((q) => {
        if (q.optional) return true;
        const v = answers[q.id];
        return v !== undefined && v !== "" && !(Array.isArray(v) && v.length === 0);
      }),
    [chapterQuestions, answers]
  );

  const completion = useMemo(() => computeCompletion(answers), [answers]);

  const startDiagnostic = useCallback(() => {
    setScreen("wizard");
    setChapterIndex(0);
  }, []);

  const nextChapter = useCallback(() => {
    if (chapterIndex < CHAPTERS.length - 1) {
      setChapterIndex((i) => i + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setScreen("report");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [chapterIndex]);

  const prevChapter = useCallback(() => {
    if (chapterIndex > 0) {
      setChapterIndex((i) => i - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setScreen("intro");
    }
  }, [chapterIndex]);

  const reset = useCallback(() => {
    setAnswers({});
    setChapterIndex(0);
    setScreen("intro");
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* noop */
    }
    window.scrollTo({ top: 0 });
  }, []);

  const diagnosis = useMemo(() => (screen === "report" ? runDiagnosis(answers) : null), [screen, answers]);

  return {
    screen,
    setScreen,
    chapterIndex,
    chapter,
    chapterQuestions,
    chapterComplete,
    answers,
    setAnswer,
    completion,
    startDiagnostic,
    nextChapter,
    prevChapter,
    reset,
    diagnosis,
    totalChapters: CHAPTERS.length,
  };
}
