import type { DimensionDef, LifecycleStageId } from "../types/churn";

/** The 10 dimensions of the Retention Intelligence model. Weights sum to 1.0
 * and represent revenue-relevance — how much a weakness here tends to
 * translate into lost recurring revenue. */
export const DIMENSIONS: DimensionDef[] = [
  {
    id: "churn-visibility",
    name: "Churn Visibility",
    shortName: "Visibility",
    description: "Whether the business can actually see and explain its own churn.",
    weight: 0.1,
  },
  {
    id: "churn-pattern",
    name: "Churn Pattern Intelligence",
    shortName: "Pattern Intelligence",
    description: "Whether churn is understood by segment, cohort, and cause — not just in aggregate.",
    weight: 0.08,
  },
  {
    id: "onboarding-ttv",
    name: "Onboarding & Time-to-Value",
    shortName: "Onboarding",
    description: "Whether customers reach meaningful value quickly and consistently.",
    weight: 0.12,
    lifecycleStage: "onboarding",
  },
  {
    id: "adoption",
    name: "Product / Service Adoption",
    shortName: "Adoption",
    description: "Whether customers actually use what they bought.",
    weight: 0.1,
    lifecycleStage: "adoption",
  },
  {
    id: "health-signals",
    name: "Customer Health Signals",
    shortName: "Health Signals",
    description: "Whether leading indicators of churn are visible before cancellation.",
    weight: 0.12,
    lifecycleStage: "ongoing-health",
  },
  {
    id: "intervention",
    name: "Retention Intervention",
    shortName: "Intervention",
    description: "Whether the business acts before the customer decides to leave.",
    weight: 0.1,
    lifecycleStage: "ongoing-health",
  },
  {
    id: "renewal",
    name: "Renewal Management",
    shortName: "Renewal",
    description: "Whether renewal is a managed revenue event rather than a deadline.",
    weight: 0.1,
    lifecycleStage: "renewal",
  },
  {
    id: "value-realization",
    name: "Value Realization",
    shortName: "Value Realization",
    description: "Whether the business can prove customers are getting the promised outcome.",
    weight: 0.1,
    lifecycleStage: "value",
  },
  {
    id: "experience-alignment",
    name: "Experience & Expectation Alignment",
    shortName: "Expectation Alignment",
    description: "Whether service, support, and delivery match what was promised at the sale.",
    weight: 0.1,
    lifecycleStage: "promise",
  },
  {
    id: "economics-awareness",
    name: "Retention Economics Awareness",
    shortName: "Economics Awareness",
    description: "Whether leadership understands the real revenue and lifetime-value impact of churn.",
    weight: 0.08,
  },
];

export const DIMENSION_MAP: Record<string, DimensionDef> = Object.fromEntries(
  DIMENSIONS.map((d) => [d.id, d])
);

export const LIFECYCLE_STAGES: { id: LifecycleStageId; label: string; description: string }[] = [
  { id: "promise", label: "Promise & Sale", description: "What was sold vs. what is delivered" },
  { id: "onboarding", label: "Onboarding", description: "First path to value" },
  { id: "adoption", label: "Adoption", description: "Ongoing use of the core value" },
  { id: "value", label: "Value Realization", description: "Proof the outcome is being delivered" },
  { id: "ongoing-health", label: "Ongoing Health", description: "Signals & intervention before risk escalates" },
  { id: "renewal", label: "Renewal", description: "The moment revenue is re-committed or lost" },
];
