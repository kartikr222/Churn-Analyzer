import { Shell } from "./components/layout/Shell";
import { IntroScreen } from "./components/intro/IntroScreen";
import { DiagnosticWizard } from "./components/diagnostic/DiagnosticWizard";
import { ReportScreen } from "./components/report/ReportScreen";
import { useChurnDiagnostic } from "./hooks/useChurnDiagnostic";

export default function App() {
  const diag = useChurnDiagnostic();

  return (
    <Shell onReset={diag.reset} showReset={diag.screen !== "intro"}>
      {diag.screen === "intro" && <IntroScreen onStart={diag.startDiagnostic} />}
      {diag.screen === "wizard" && <DiagnosticWizard {...diag} />}
      {diag.screen === "report" && diag.diagnosis && <ReportScreen diagnosis={diag.diagnosis} onReset={diag.reset} />}
    </Shell>
  );
}
