/** Core diagnostic types for Churn Analyzer™ — Retention Intelligence. */

export type DimensionId =
  | "churn-visibility"
  | "churn-pattern"
  | "onboarding-ttv"
  | "adoption"
  | "health-signals"
  | "intervention"
  | "renewal"
  | "value-realization"
  | "experience-alignment"
  | "economics-awareness";

export type LifecycleStageId =
  | "promise"
  | "onboarding"
  | "adoption"
  | "value"
  | "ongoing-health"
  | "renewal";

export type EvidenceQuality = "known" | "estimated" | "unknown";

export type QuestionInputType = "single" | "multi" | "number" | "currency" | "percent";

export interface AnswerOption {
  id: string;
  label: string;
  /** 0 = missing/critical gap, 1 = weak, 2 = adequate, 3 = strong */
  maturity: 0 | 1 | 2 | 3;
  /** marks this option as an admission that the data/process does not exist */
  isUnknown?: boolean;
  helper?: string;
}

export interface QuestionDef {
  id: string;
  chapterId: ChapterId;
  dimensionIds: DimensionId[];
  prompt: string;
  context?: string;
  type: QuestionInputType;
  options?: AnswerOption[];
  placeholder?: string;
  unit?: string;
  optional?: boolean;
  /** only render this question if the predicate over current answers returns true */
  showIf?: (answers: AnswerMap, ctx: BaselineContext) => boolean;
  /** dynamic label overrides based on business model, e.g. "renewal" -> "repurchase" */
  labelFor?: (ctx: BaselineContext) => string | undefined;
  min?: number;
  max?: number;
}

export interface ChapterDef {
  id: ChapterId;
  index: number;
  title: string;
  kicker: string;
  description: string;
  questions: QuestionDef[];
}

export type ChapterId =
  | "baseline"
  | "churn-reality"
  | "customer-journey"
  | "early-warning"
  | "operating-system"
  | "economics";

export type AnswerValue = string | string[] | number | undefined;

export interface AnswerMap {
  [questionId: string]: AnswerValue;
}

export interface BaselineContext {
  businessModel?: string;
  customerType?: string;
  cycleLabel?: string;
}

export interface DimensionDef {
  id: DimensionId;
  name: string;
  shortName: string;
  description: string;
  /** revenue-relevance weight — all dimension weights sum to 1 */
  weight: number;
  lifecycleStage?: LifecycleStageId;
}

export type RiskLevel = "critical" | "high" | "moderate" | "low";

export interface DimensionResult {
  id: DimensionId;
  score: number; // 0-100
  risk: RiskLevel;
  answeredCount: number;
  totalCount: number;
  unknownCount: number;
  confidence: EvidenceQuality;
  driverQuestions: {
    questionId: string;
    prompt: string;
    selectedLabel: string;
    maturity: number;
    isUnknown: boolean;
  }[];
}

export type HealthBand =
  | "advantage"
  | "stable"
  | "exposed"
  | "leaking"
  | "critical";

export interface OverallHealth {
  score: number; // 0-100
  band: HealthBand;
  label: string;
  narrative: string;
}

export interface RevenueFigure {
  value: number | null;
  source: "user" | "calculated" | "estimated" | "inference";
}

export interface RevenueImpact {
  currencySymbol: string;
  mrr: RevenueFigure;
  monthlyChurnRatePct: RevenueFigure;
  customersLostMonthly: RevenueFigure;
  monthlyRevenueAtRisk: RevenueFigure;
  annualizedRevenueAtRisk: RevenueFigure;
  approximateLtv: RevenueFigure;
  scenarios: { reductionPct: number; annualRevenuePreserved: number }[];
  hasSufficientData: boolean;
  missingInputs: string[];
}

export interface LifecycleStageResult {
  id: LifecycleStageId;
  label: string;
  score: number;
  risk: RiskLevel;
  dimensionIds: DimensionId[];
}

export interface DiagnosisResult {
  overall: OverallHealth;
  dimensions: DimensionResult[];
  lifecycle: LifecycleStageResult[];
  revenue: RevenueImpact;
  topRisks: { dimension: DimensionResult; def: DimensionDef; severityScore: number }[];
  hiddenRisk: { dimension: DimensionResult; def: DimensionDef; reason: string } | null;
  strongestAsset: { dimension: DimensionResult; def: DimensionDef };
  earlyWarningGap: string;
  rootCause: { headline: string; explanation: string; evidenceSource: "reported" | "inferred" };
  priorityActions: string[];
  plan30: string[];
  plan90: string[];
  whatToMeasureNext: string[];
  confidenceNote: string | null;
}
