import { ArrowRight, Eye, GitBranch, LineChart, ShieldAlert } from "lucide-react";
import { Button, Kicker } from "../ui/primitives";
import { RectangleLogoOnLight } from "../brand/Logo";
import { DIMENSIONS } from "../../data/dimensions";

const PILLARS = [
  {
    icon: Eye,
    title: "Establish your retention baseline",
    body: "Separate what you actually know about churn from what you assume.",
  },
  {
    icon: GitBranch,
    title: "Trace the customer lifecycle",
    body: "Locate exactly where value, adoption, and trust break down.",
  },
  {
    icon: ShieldAlert,
    title: "Test your early-warning coverage",
    body: "See whether risk is visible before cancellation — or only after.",
  },
  {
    icon: LineChart,
    title: "Quantify the revenue exposure",
    body: "Turn the diagnosis into a number your CFO can act on.",
  },
];

export function IntroScreen({ onStart }: { onStart: () => void }) {
  return (
    <div>
      <section className="brand-grid-field relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <svg viewBox="0 0 800 400" className="h-full w-full" preserveAspectRatio="none">
            <path
              d="M0 320 C 100 260, 140 340, 220 260 S 340 160, 420 210 S 540 100, 620 140 S 740 60, 800 90"
              stroke="#5fd0ec"
              strokeOpacity="0.35"
              strokeWidth="2"
              fill="none"
            />
            <path
              d="M0 360 C 120 320, 160 370, 260 320 S 380 240, 460 270 S 580 190, 660 220 S 760 150, 800 170"
              stroke="#93aeea"
              strokeOpacity="0.25"
              strokeWidth="2"
              fill="none"
            />
          </svg>
        </div>
        <div className="relative mx-auto max-w-4xl px-6 pb-20 pt-16 text-center sm:px-8 sm:pb-28 sm:pt-24">
          <div className="animate-rise mb-10 flex justify-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 font-mono text-[0.68rem] uppercase tracking-[0.18em] text-sky-200">
              Kartik Clarity™ Diagnostic Suite
            </span>
          </div>
          <h1
            className="animate-rise text-balance text-4xl font-semibold tracking-tight text-white sm:text-6xl"
            style={{ animationDelay: "60ms" }}
          >
            Churn Analyzer<span className="align-super text-2xl sm:text-3xl">™</span>
          </h1>
          <p
            className="animate-rise mt-3 text-lg font-medium text-sky-200 sm:text-xl"
            style={{ animationDelay: "110ms" }}
          >
            Retention Intelligence
          </p>
          <p
            className="animate-rise text-balance mx-auto mt-7 max-w-2xl text-base leading-relaxed text-white/75 sm:text-lg"
            style={{ animationDelay: "160ms" }}
          >
            Find the revenue leaving before you know it's gone. A deterministic diagnostic across ten dimensions of
            your retention system — not another churn-rate calculator.
          </p>
          <div className="animate-rise mt-10 flex flex-col items-center gap-3" style={{ animationDelay: "220ms" }}>
            <Button variant="light" onClick={onStart} className="px-7 py-3.5 text-base">
              Start Retention Diagnosis
              <ArrowRight className="h-4 w-4" />
            </Button>
            <span className="font-mono text-[0.68rem] uppercase tracking-[0.14em] text-white/40">
              ~8 minutes · 6 diagnostic chapters · no account required
            </span>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8 sm:py-20">
        <div className="mb-12 max-w-2xl">
          <Kicker>How this diagnostic works</Kicker>
          <h2 className="text-balance mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
            This isn't a survey. It's a retention-system diagnosis.
          </h2>
          <p className="mt-4 text-[0.95rem] leading-relaxed text-ink-soft">
            Every question maps to a specific, weighted dimension of retention health. Your score is never assigned
            arbitrarily — it's computed deterministically from what you actually know, what you don't, and what that
            gap implies.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((p, i) => (
            <div
              key={p.title}
              className="animate-rise rounded-2xl border border-line bg-white p-6 shadow-[var(--shadow-card)]"
              style={{ animationDelay: `${i * 70}ms` }}
            >
              <p.icon className="h-5 w-5 text-sky-600" strokeWidth={1.75} />
              <h3 className="mt-4 text-sm font-semibold text-navy-900">{p.title}</h3>
              <p className="mt-2 text-[0.83rem] leading-relaxed text-ink-soft">{p.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="border-y border-line bg-navy-50/50">
        <div className="mx-auto max-w-6xl px-6 py-16 sm:px-8 sm:py-20">
          <Kicker>The diagnostic model</Kicker>
          <h2 className="mt-3 max-w-2xl text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
            Ten dimensions. One retention health index.
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-x-8 gap-y-5 sm:grid-cols-2">
            {DIMENSIONS.map((d, i) => (
              <div key={d.id} className="flex items-start gap-4 border-b border-line/70 pb-5">
                <span className="mt-0.5 font-mono text-xs text-navy-300">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <p className="text-sm font-semibold text-navy-900">{d.name}</p>
                  <p className="mt-1 text-[0.82rem] leading-relaxed text-ink-soft">{d.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-16 text-center sm:px-8 sm:py-24">
        <RectangleLogoOnLight className="mx-auto mb-8 justify-center" />
        <h2 className="text-balance text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
          Leave with a revenue number, a root cause, and a 30/90-day plan.
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-[0.95rem] leading-relaxed text-ink-soft">
          Not a percentage. An executive-grade diagnosis: where churn concentrates, what it's costing you, and the
          highest-leverage fix to make first.
        </p>
        <Button onClick={onStart} className="mx-auto mt-9">
          Start Retention Diagnosis
          <ArrowRight className="h-4 w-4" />
        </Button>
      </section>
    </div>
  );
}
