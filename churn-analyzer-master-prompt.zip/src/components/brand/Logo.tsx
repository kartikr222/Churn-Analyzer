import { cn } from "../../utils/cn";

/**
 * Kartik Clarity™ brand mark, reconstructed as scalable inline SVG using the
 * brand's authoritative visual language: a deep navy gradient field, a fine
 * ascending market-line motif, and the "eye · bars · shield · arrow" emblem
 * that appears on the brand's own apparel/lockups, paired with the
 * "Kartik Clarity" wordmark and "Think. Focus. Achieve." tagline.
 */

function BrandMark({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id="kc-mark-grad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#5fd0ec" />
          <stop offset="100%" stopColor="#c9d8f7" />
        </linearGradient>
      </defs>
      {/* shield */}
      <path
        d="M24 3.5 40 9v11.5c0 11.2-6.9 18.9-16 24-9.1-5.1-16-12.8-16-24V9L24 3.5Z"
        stroke="url(#kc-mark-grad)"
        strokeWidth="2.1"
        strokeLinejoin="round"
      />
      {/* ascending bars */}
      <rect x="14.5" y="26" width="3.4" height="8" rx="0.8" fill="url(#kc-mark-grad)" />
      <rect x="20" y="21.5" width="3.4" height="12.5" rx="0.8" fill="url(#kc-mark-grad)" />
      <rect x="25.5" y="24" width="3.4" height="10" rx="0.8" fill="url(#kc-mark-grad)" opacity="0.55" />
      {/* arrow */}
      <path
        d="M14 20.5 21 14l4 4 8.5-8.5"
        stroke="url(#kc-mark-grad)"
        strokeWidth="2.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M27 9.2h6.5v6.5" stroke="url(#kc-mark-grad)" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
      {/* eye, bottom accent */}
      <circle cx="24" cy="30.4" r="2.1" fill="#081334" stroke="url(#kc-mark-grad)" strokeWidth="1.1" opacity="0.9" />
    </svg>
  );
}

function MarketLines({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 400 160"
      preserveAspectRatio="none"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M0 120 C 40 100, 60 130, 100 95 S 160 60, 200 80 S 260 40, 300 55 S 360 20, 400 30"
        stroke="white"
        strokeOpacity="0.16"
        strokeWidth="2"
        fill="none"
      />
      <path
        d="M0 140 C 50 125, 70 145, 120 118 S 190 90, 230 100 S 290 70, 340 78 S 380 55, 400 60"
        stroke="white"
        strokeOpacity="0.09"
        strokeWidth="2"
        fill="none"
      />
      {Array.from({ length: 10 }).map((_, i) => (
        <rect key={i} x={i * 42} y={150 - (i % 5) * 10 - 20} width="10" height={(i % 5) * 10 + 20} fill="white" opacity="0.05" />
      ))}
    </svg>
  );
}

/** Compact circular badge — for favicons-in-page, avatars, footer marks. */
export function CircleLogo({ size = 40, className }: { size?: number; className?: string }) {
  return (
    <div
      className={cn("relative shrink-0 overflow-hidden rounded-full ring-1 ring-white/15", className)}
      style={{ width: size, height: size }}
    >
      <div className="brand-grid-field absolute inset-0" />
      <MarketLines className="absolute inset-0 h-full w-full" />
      <div className="absolute inset-0 flex items-center justify-center">
        <BrandMark size={Math.round(size * 0.52)} />
      </div>
    </div>
  );
}

/** Full horizontal lockup — for header / hero brand placement. */
export function RectangleLogo({
  className,
  showTagline = true,
}: {
  className?: string;
  showTagline?: boolean;
}) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <CircleLogo size={38} />
      <div className="flex flex-col leading-none">
        <span
          className="text-[1.05rem] font-semibold tracking-tight text-white"
          style={{ fontFamily: "var(--font-sans)" }}
        >
          Kartik Clarity<span className="align-super text-[0.5rem] font-normal">™</span>
        </span>
        {showTagline && (
          <span className="mt-1 text-[0.62rem] font-medium uppercase tracking-[0.16em] text-sky-200/80">
            Think. Focus. Achieve.
          </span>
        )}
      </div>
    </div>
  );
}

/** Full horizontal lockup for light backgrounds (navy text instead of white). */
export function RectangleLogoOnLight({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <CircleLogo size={34} />
      <div className="flex flex-col leading-none">
        <span className="text-[0.98rem] font-semibold tracking-tight text-navy-900">
          Kartik Clarity<span className="align-super text-[0.48rem] font-normal">™</span>
        </span>
        <span className="mt-1 text-[0.58rem] font-medium uppercase tracking-[0.16em] text-navy-400">
          Think. Focus. Achieve.
        </span>
      </div>
    </div>
  );
}
