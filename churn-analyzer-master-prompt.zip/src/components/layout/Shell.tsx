import type { ReactNode } from "react";
import { CircleLogo, RectangleLogo } from "../brand/Logo";

export function Header({ onReset, showReset }: { onReset: () => void; showReset: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-navy-900/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5 sm:px-8">
        <RectangleLogo />
        <div className="flex items-center gap-4">
          <span className="hidden font-mono text-[0.68rem] uppercase tracking-[0.14em] text-sky-200/70 sm:inline">
            Churn Analyzer™ · Retention Intelligence
          </span>
          {showReset && (
            <button
              onClick={onReset}
              className="rounded-full border border-white/15 px-3.5 py-1.5 text-xs font-semibold text-white/80 transition hover:border-white/30 hover:text-white"
            >
              Start Over
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-line bg-white">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-5 py-10 text-center sm:flex-row sm:justify-between sm:text-left">
        <div className="flex items-center gap-3">
          <CircleLogo size={32} />
          <div className="text-xs text-ink-soft">
            <p className="font-semibold text-navy-800">Kartik Clarity™</p>
            <p>Think. Focus. Achieve.</p>
          </div>
        </div>
        <p className="max-w-md text-[0.72rem] leading-relaxed text-ink-soft">
          Churn Analyzer™ is a diagnostic instrument, not a certified financial or legal analysis. Figures marked
          Estimated or Diagnostic Inference are directional and should be validated against your own records.
        </p>
      </div>
    </footer>
  );
}

export function Shell({ children, onReset, showReset }: { children: ReactNode; onReset: () => void; showReset: boolean }) {
  return (
    <div className="flex min-h-screen flex-col bg-paper">
      <Header onReset={onReset} showReset={showReset} />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
