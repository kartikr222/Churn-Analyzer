import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "../../utils/cn";
import type { RiskLevel } from "../../types/churn";

export function Button({
  variant = "primary",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "light" }) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-all duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 disabled:cursor-not-allowed disabled:opacity-40";
  const styles = {
    primary:
      "bg-navy-900 text-white hover:bg-navy-800 active:bg-navy-950 shadow-[0_1px_2px_rgba(8,19,52,0.15)]",
    light: "bg-white text-navy-900 hover:bg-sky-100",
    ghost: "bg-transparent text-navy-700 hover:bg-navy-50",
  }[variant];
  return (
    <button className={cn(base, styles, className)} {...rest}>
      {children}
    </button>
  );
}

export function Kicker({ children, tone = "dark" }: { children: ReactNode; tone?: "dark" | "light" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 text-[0.7rem] font-semibold uppercase tracking-[0.18em]",
        tone === "dark" ? "text-navy-400" : "text-sky-300"
      )}
    >
      <span className={cn("h-1 w-1 rounded-full", tone === "dark" ? "bg-navy-400" : "bg-sky-300")} />
      {children}
    </span>
  );
}

const RISK_STYLE: Record<RiskLevel, { label: string; dot: string; text: string; bg: string }> = {
  critical: { label: "Critical", dot: "bg-alert-600", text: "text-alert-700", bg: "bg-alert-100" },
  high: { label: "High Risk", dot: "bg-alert-400", text: "text-alert-600", bg: "bg-alert-100" },
  moderate: { label: "Moderate", dot: "bg-navy-300", text: "text-navy-600", bg: "bg-navy-50" },
  low: { label: "Strength", dot: "bg-sky-500", text: "text-sky-600", bg: "bg-sky-100" },
};

export function RiskBadge({ risk, className }: { risk: RiskLevel; className?: string }) {
  const s = RISK_STYLE[risk];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.68rem] font-semibold uppercase tracking-wide",
        s.bg,
        s.text,
        className
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {s.label}
    </span>
  );
}

export type DataSource = "user" | "calculated" | "estimated" | "inference";

const SOURCE_LABEL: Record<DataSource, string> = {
  user: "Your Data",
  calculated: "Calculated",
  estimated: "Estimated",
  inference: "Diagnostic Inference",
};

export function DataTag({ source, className }: { source: DataSource; className?: string }) {
  const styleMap: Record<DataSource, string> = {
    user: "bg-navy-50 text-navy-600 border-navy-100",
    calculated: "bg-sky-100 text-sky-700 border-sky-200",
    estimated: "border-navy-100 bg-white text-navy-400",
    inference: "border-alert-200 bg-alert-100 text-alert-700",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded border px-1.5 py-0.5 font-mono text-[0.62rem] font-medium uppercase tracking-wide",
        styleMap[source],
        className
      )}
    >
      {SOURCE_LABEL[source]}
    </span>
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-line bg-white p-6 shadow-[var(--shadow-card)]",
        className
      )}
    >
      {children}
    </div>
  );
}

export function formatCurrency(value: number | null, symbol = "$"): string {
  if (value === null) return "—";
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `${symbol}${(value / 1_000_000).toFixed(1)}M`;
  if (abs >= 1_000) return `${symbol}${Math.round(value).toLocaleString("en-US")}`;
  return `${symbol}${value.toFixed(0)}`;
}
