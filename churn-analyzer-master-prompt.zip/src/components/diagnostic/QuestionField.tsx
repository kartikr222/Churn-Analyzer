import { Check } from "lucide-react";
import type { AnswerValue, BaselineContext, QuestionDef } from "../../types/churn";
import { cn } from "../../utils/cn";

interface Props {
  question: QuestionDef;
  value: AnswerValue;
  onChange: (value: AnswerValue) => void;
  ctx: BaselineContext;
}

export function QuestionField({ question, value, onChange, ctx }: Props) {
  const prompt = question.labelFor?.(ctx) ?? question.prompt;

  return (
    <div className="animate-rise border-b border-line py-7 first:pt-0 last:border-b-0">
      <div className="flex items-start justify-between gap-4">
        <label className="block text-[1.02rem] font-medium leading-snug text-navy-900" id={`${question.id}-label`} htmlFor={question.id}>
          {prompt}
        </label>
        {question.optional && (
          <span className="shrink-0 rounded-full bg-navy-50 px-2.5 py-0.5 font-mono text-[0.62rem] uppercase tracking-wide text-navy-400">
            Optional
          </span>
        )}
      </div>
      {question.context && <p className="mt-1.5 text-[0.82rem] text-ink-soft">{question.context}</p>}

      <div className="mt-4">
        {question.type === "single" && question.options && (
          <div
            className="grid grid-cols-1 gap-2.5 sm:grid-cols-2"
            role="radiogroup"
            aria-labelledby={`${question.id}-label`}
          >
            {question.options.map((opt) => {
              const active = value === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => onChange(opt.id)}
                  className={cn(
                    "group flex items-center gap-3 rounded-xl border px-4 py-3 text-left text-sm transition-all duration-150",
                    active
                      ? "border-navy-700 bg-navy-900 text-white shadow-[var(--shadow-card)]"
                      : "border-line bg-white text-navy-800 hover:border-navy-300 hover:bg-navy-50/60"
                  )}
                >
                  <span
                    className={cn(
                      "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border transition-colors",
                      active ? "border-sky-300 bg-sky-300/20" : "border-navy-200"
                    )}
                  >
                    {active && <Check className="h-2.5 w-2.5 text-sky-200" strokeWidth={3} />}
                  </span>
                  <span className="leading-snug">{opt.label}</span>
                </button>
              );
            })}
          </div>
        )}

        {question.type === "multi" && question.options && (
          <div className="flex flex-wrap gap-2.5">
            {question.options.map((opt) => {
              const arr = Array.isArray(value) ? value : [];
              const active = arr.includes(opt.id);
              return (
                <button
                  key={opt.id}
                  type="button"
                  aria-pressed={active}
                  onClick={() => {
                    const next = active ? arr.filter((v) => v !== opt.id) : [...arr, opt.id];
                    onChange(next);
                  }}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-[0.83rem] font-medium transition-all duration-150",
                    active
                      ? "border-navy-700 bg-navy-900 text-white"
                      : "border-line bg-white text-navy-700 hover:border-navy-300 hover:bg-navy-50/60"
                  )}
                >
                  {active && <Check className="h-3 w-3 text-sky-200" strokeWidth={3} />}
                  {opt.label}
                </button>
              );
            })}
          </div>
        )}

        {(question.type === "number" || question.type === "currency" || question.type === "percent") && (
          <div className="max-w-xs">
            <div
              className={cn(
                "flex items-center rounded-xl border bg-white px-4 py-3 transition-colors focus-within:border-navy-500",
                "border-line"
              )}
            >
              {question.type === "currency" && <span className="mr-2 font-mono text-sm text-navy-400">$</span>}
              <input
                id={question.id}
                type="number"
                inputMode="decimal"
                min={question.min}
                max={question.max}
                placeholder={question.placeholder}
                value={value === undefined ? "" : String(value)}
                onChange={(e) => {
                  const raw = e.target.value;
                  onChange(raw === "" ? undefined : Number(raw));
                }}
                className="w-full bg-transparent font-mono text-sm text-navy-900 outline-none placeholder:text-navy-200"
              />
              {question.type === "percent" && <span className="ml-2 font-mono text-sm text-navy-400">%</span>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
