import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { CHAPTERS } from "../../data/questions";
import { QuestionField } from "./QuestionField";
import { Button } from "../ui/primitives";
import { cn } from "../../utils/cn";
import type { useChurnDiagnostic } from "../../hooks/useChurnDiagnostic";
import { getBaselineContext } from "../../engine/scoring";

export function DiagnosticWizard(props: ReturnType<typeof useChurnDiagnostic>) {
  const { chapter, chapterIndex, chapterQuestions, chapterComplete, answers, setAnswer, nextChapter, prevChapter, totalChapters, completion } =
    props;

  if (!chapter) return null;
  const ctx = getBaselineContext(answers);

  return (
    <div className="mx-auto grid max-w-6xl grid-cols-1 gap-10 px-5 py-10 sm:px-8 sm:py-14 lg:grid-cols-[220px_1fr]">
      {/* progress rail */}
      <aside className="lg:sticky lg:top-24 lg:self-start">
        <div className="mb-6 hidden lg:block">
          <p className="font-mono text-[0.68rem] uppercase tracking-[0.14em] text-navy-400">Overall progress</p>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-navy-50">
            <div
              className="h-full rounded-full bg-navy-700 transition-all duration-500"
              style={{ width: `${completion.pct}%` }}
            />
          </div>
          <p className="mt-1.5 font-mono text-[0.68rem] text-ink-soft">{completion.pct}% complete</p>
        </div>
        <ol className="flex gap-3 overflow-x-auto pb-2 lg:flex-col lg:gap-1 lg:overflow-visible lg:pb-0">
          {CHAPTERS.map((c, i) => {
            const state = i < chapterIndex ? "done" : i === chapterIndex ? "active" : "upcoming";
            return (
              <li key={c.id} className="shrink-0 lg:shrink">
                <div
                  className={cn(
                    "flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[0.8rem] transition-colors lg:px-3",
                    state === "active" && "bg-navy-900 text-white",
                    state === "done" && "text-navy-700",
                    state === "upcoming" && "text-navy-300"
                  )}
                >
                  <span
                    className={cn(
                      "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border font-mono text-[0.62rem]",
                      state === "active" && "border-sky-300 bg-sky-300/20 text-sky-200",
                      state === "done" && "border-navy-500 bg-navy-500 text-white",
                      state === "upcoming" && "border-navy-100 text-navy-300"
                    )}
                  >
                    {state === "done" ? <Check className="h-3 w-3" strokeWidth={3} /> : i + 1}
                  </span>
                  <span className="whitespace-nowrap font-medium lg:whitespace-normal">{c.title}</span>
                </div>
              </li>
            );
          })}
        </ol>
      </aside>

      {/* chapter content */}
      <div className="animate-fade" key={chapter.id}>
        <p className="font-mono text-[0.7rem] uppercase tracking-[0.16em] text-sky-600">{chapter.kicker}</p>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-navy-900 sm:text-[1.75rem]">{chapter.title}</h1>
        <p className="mt-3 max-w-xl text-[0.92rem] leading-relaxed text-ink-soft">{chapter.description}</p>

        <div className="mt-8 rounded-2xl border border-line bg-white px-6 shadow-[var(--shadow-card)] sm:px-8">
          {chapterQuestions.map((q) => (
            <QuestionField key={q.id} question={q} value={answers[q.id]} onChange={(v) => setAnswer(q.id, v)} ctx={ctx} />
          ))}
        </div>

        <div className="mt-8 flex items-center justify-between">
          <button
            onClick={prevChapter}
            className="inline-flex items-center gap-2 text-sm font-semibold text-navy-500 transition hover:text-navy-800"
          >
            <ArrowLeft className="h-4 w-4" />
            {chapterIndex === 0 ? "Back to intro" : "Back"}
          </button>
          <Button onClick={nextChapter} disabled={!chapterComplete}>
            {chapterIndex === totalChapters - 1 ? "Generate Diagnosis" : "Continue"}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        {!chapterComplete && (
          <p className="mt-3 text-right font-mono text-[0.68rem] uppercase tracking-wide text-navy-300">
            Answer required fields to continue
          </p>
        )}
      </div>
    </div>
  );
}
