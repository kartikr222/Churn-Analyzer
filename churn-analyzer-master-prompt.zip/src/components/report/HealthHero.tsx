import type { OverallHealth } from "../../types/churn";
import { cn } from "../../utils/cn";

const BAND_ACCENT: Record<OverallHealth["band"], string> = {
  advantage: "#5fd0ec",
  stable: "#93aeea",
  exposed: "#d98a55",
  leaking: "#c2542f",
  critical: "#8a3420",
};

function Gauge({ score, color }: { score: number; color: string }) {
  const radius = 84;
  const circumference = Math.PI * radius; // half circle
  const offset = circumference * (1 - score / 100);

  return (
    <svg viewBox="0 0 200 116" className="w-full max-w-[280px]">
      <path
        d="M 16 108 A 84 84 0 0 1 184 108"
        fill="none"
        stroke="rgba(255,255,255,0.12)"
        strokeWidth="14"
        strokeLinecap="round"
      />
      <path
        d="M 16 108 A 84 84 0 0 1 184 108"
        fill="none"
        stroke={color}
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        className="animate-grow"
        style={{ animationDuration: "1.1s" }}
        transform="scale(1,1)"
      />
      <text x="100" y="92" textAnchor="middle" className="font-mono" fill="white" fontSize="40" fontWeight={600}>
        {score}
      </text>
      <text x="100" y="110" textAnchor="middle" fill="rgba(255,255,255,0.5)" fontSize="10" letterSpacing="1.5">
        RETENTION HEALTH INDEX
      </text>
    </svg>
  );
}

export function HealthHero({ overall, confidenceNote }: { overall: OverallHealth; confidenceNote: string | null }) {
  const color = BAND_ACCENT[overall.band];
  return (
    <section className="brand-grid-field relative overflow-hidden">
      <div className="relative mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 px-6 py-16 sm:px-8 sm:py-20 lg:grid-cols-[1fr_auto]">
        <div>
          <p className="font-mono text-[0.7rem] uppercase tracking-[0.18em] text-sky-300">Diagnosis Complete</p>
          <h1
            className="mt-3 text-3xl font-semibold tracking-tight text-white sm:text-4xl"
            style={{ color }}
          >
            {overall.label}
          </h1>
          <p className="mt-5 max-w-xl text-[0.98rem] leading-relaxed text-white/75">{overall.narrative}</p>
          {confidenceNote && (
            <p className="mt-4 max-w-xl rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-[0.8rem] leading-relaxed text-sky-200/90">
              {confidenceNote}
            </p>
          )}
        </div>
        <div className={cn("flex justify-center")}>
          <Gauge score={overall.score} color={color} />
        </div>
      </div>
    </section>
  );
}
