import { useState } from "react";
import { ChevronDown } from "lucide-react";
import type { DimensionResult } from "../../types/churn";
import { DIMENSION_MAP } from "../../data/dimensions";
import { Kicker, RiskBadge } from "../ui/primitives";
import { cn } from "../../utils/cn";

function DimensionRow({ result }: { result: DimensionResult }) {
  const [open, setOpen] = useState(false);
  const def = DIMENSION_MAP[result.id];

  return (
    <div className="border-b border-line last:border-b-0">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center gap-4 py-4 text-left"
        aria-expanded={open}
      >
        <span className="w-52 shrink-0 text-sm font-medium text-navy-900 sm:w-64">{def.name}</span>
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-navy-50">
          <div
            className={cn(
              "animate-grow h-full rounded-full",
              result.risk === "critical" && "bg-alert-600",
              result.risk === "high" && "bg-alert-400",
              result.risk === "moderate" && "bg-navy-300",
              result.risk === "low" && "bg-sky-500"
            )}
            style={{ width: `${result.score}%` }}
          />
        </div>
        <span className="w-10 shrink-0 text-right font-mono text-sm text-navy-500">{result.score}</span>
        <RiskBadge risk={result.risk} className="hidden shrink-0 sm:inline-flex" />
        <ChevronDown className={cn("h-4 w-4 shrink-0 text-navy-300 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="animate-fade pb-5 pl-0 sm:pl-64">
          <p className="mb-3 max-w-xl text-[0.83rem] leading-relaxed text-ink-soft">{def.description}</p>
          {result.driverQuestions.length === 0 ? (
            <p className="text-[0.8rem] italic text-navy-300">No evidence supplied for this dimension.</p>
          ) : (
            <ul className="space-y-2">
              {result.driverQuestions.map((d) => (
                <li key={d.questionId} className="flex flex-wrap items-center gap-x-2 text-[0.8rem] text-ink-soft">
                  <span className="font-medium text-navy-700">{d.prompt}</span>
                  <span>→</span>
                  <span className={cn(d.isUnknown ? "text-alert-600" : "text-navy-600")}>{d.selectedLabel}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

export function DiagnosticComposition({ dimensions }: { dimensions: DimensionResult[] }) {
  const sorted = [...dimensions].sort((a, b) => DIMENSION_MAP[b.id].weight - DIMENSION_MAP[a.id].weight);
  return (
    <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
      <Kicker>Full diagnostic composition</Kicker>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
        Every dimension, with the evidence behind it
      </h2>
      <p className="mt-3 max-w-2xl text-[0.92rem] leading-relaxed text-ink-soft">
        Expand any dimension to see exactly which answers produced its score — nothing here is a black box.
      </p>
      <div className="mt-8 rounded-2xl border border-line bg-white px-5 shadow-[var(--shadow-card)] sm:px-7">
        {sorted.map((r) => (
          <DimensionRow key={r.id} result={r} />
        ))}
      </div>
    </section>
  );
}

export function PriorityMatrix({ dimensions }: { dimensions: DimensionResult[] }) {
  const quadrantOf = (r: DimensionResult) => {
    const highWeight = DIMENSION_MAP[r.id].weight >= 0.1;
    const highSeverity = r.score < 55;
    if (highWeight && highSeverity) return "critical";
    if (highWeight && !highSeverity) return "monitor";
    if (!highWeight && highSeverity) return "quick-win";
    return "low";
  };

  const quadrants: { id: string; title: string; hint: string; accent: string }[] = [
    { id: "critical", title: "Critical priorities", hint: "High revenue relevance · high severity", accent: "border-alert-500" },
    { id: "quick-win", title: "Quick wins", hint: "Lower relevance · high severity", accent: "border-navy-400" },
    { id: "monitor", title: "Monitor", hint: "High relevance · currently healthy", accent: "border-sky-500" },
    { id: "low", title: "Low priority", hint: "Lower relevance · currently healthy", accent: "border-navy-100" },
  ];

  return (
    <section className="border-y border-line bg-navy-50/40">
      <div className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
        <Kicker>Intervention priority matrix</Kicker>
        <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
          Where to focus first
        </h2>
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {quadrants.map((q) => {
            const items = dimensions.filter((d) => quadrantOf(d) === q.id);
            return (
              <div key={q.id} className={cn("rounded-2xl border-2 bg-white p-6", q.accent)}>
                <p className="text-sm font-semibold text-navy-900">{q.title}</p>
                <p className="mt-1 font-mono text-[0.68rem] uppercase tracking-wide text-navy-300">{q.hint}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {items.length === 0 ? (
                    <span className="text-[0.8rem] text-navy-300">None currently</span>
                  ) : (
                    items.map((d) => (
                      <span
                        key={d.id}
                        className="rounded-full bg-navy-50 px-3 py-1 text-[0.78rem] font-medium text-navy-700"
                      >
                        {DIMENSION_MAP[d.id].shortName}
                      </span>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
