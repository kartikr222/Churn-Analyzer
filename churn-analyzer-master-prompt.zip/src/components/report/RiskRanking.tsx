import { AlertTriangle, Eye, ShieldCheck } from "lucide-react";
import type { DiagnosisResult } from "../../types/churn";
import { Card, Kicker, RiskBadge } from "../ui/primitives";
import { DIMENSION_CONTENT } from "../../engine/contentTemplates";

export function RiskRanking({ topRisks }: { topRisks: DiagnosisResult["topRisks"] }) {
  return (
    <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
      <Kicker>Ranked by severity × revenue relevance</Kicker>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">Top 3 retention risks</h2>
      <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-3">
        {topRisks.map((r, i) => (
          <Card key={r.dimension.id} className="animate-rise flex flex-col" >
            <div className="flex items-start justify-between">
              <span className="font-mono text-3xl font-semibold text-navy-100">0{i + 1}</span>
              <RiskBadge risk={r.dimension.risk} />
            </div>
            <h3 className="mt-4 text-base font-semibold text-navy-900">{r.def.name}</h3>
            <div className="mt-3 flex items-center gap-2">
              <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-navy-50">
                <div className="h-full rounded-full bg-alert-500" style={{ width: `${r.dimension.score}%` }} />
              </div>
              <span className="font-mono text-xs text-navy-400">{r.dimension.score}/100</span>
            </div>
            <p className="mt-4 flex-1 text-[0.85rem] leading-relaxed text-ink-soft">
              {DIMENSION_CONTENT[r.dimension.id].riskExplanation}
            </p>
          </Card>
        ))}
      </div>
    </section>
  );
}

export function SideInsights({
  hiddenRisk,
  strongestAsset,
  earlyWarningGap,
}: Pick<DiagnosisResult, "hiddenRisk" | "strongestAsset" | "earlyWarningGap">) {
  return (
    <section className="border-y border-line bg-navy-50/40">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-5 px-6 py-16 sm:px-8 lg:grid-cols-3">
        {hiddenRisk && (
          <Card className="border-alert-200">
            <AlertTriangle className="h-5 w-5 text-alert-600" strokeWidth={1.75} />
            <p className="mt-4 font-mono text-[0.68rem] uppercase tracking-[0.14em] text-alert-600">Hidden risk</p>
            <h3 className="mt-2 text-base font-semibold text-navy-900">{hiddenRisk.def.name}</h3>
            <p className="mt-2 text-[0.85rem] leading-relaxed text-ink-soft">{hiddenRisk.reason}</p>
          </Card>
        )}
        <Card>
          <ShieldCheck className="h-5 w-5 text-sky-600" strokeWidth={1.75} />
          <p className="mt-4 font-mono text-[0.68rem] uppercase tracking-[0.14em] text-sky-600">
            Strongest retention asset
          </p>
          <h3 className="mt-2 text-base font-semibold text-navy-900">{strongestAsset.def.name}</h3>
          <p className="mt-2 text-[0.85rem] leading-relaxed text-ink-soft">
            {strongestAsset.dimension.score >= 55
              ? "This is functioning well enough to build on — protect it as the business scales."
              : "This is the least-weak part of the system — still worth reinforcing before it degrades further."}
          </p>
        </Card>
        <Card>
          <Eye className="h-5 w-5 text-navy-500" strokeWidth={1.75} />
          <p className="mt-4 font-mono text-[0.68rem] uppercase tracking-[0.14em] text-navy-500">Early-warning gap</p>
          <p className="mt-2 text-[0.85rem] leading-relaxed text-ink-soft">{earlyWarningGap}</p>
        </Card>
      </div>
    </section>
  );
}
