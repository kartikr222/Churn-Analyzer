import { Droplets } from "lucide-react";
import type { LifecycleStageResult } from "../../types/churn";
import { Kicker, RiskBadge } from "../ui/primitives";
import { cn } from "../../utils/cn";

const RISK_BAR: Record<LifecycleStageResult["risk"], string> = {
  critical: "bg-alert-600",
  high: "bg-alert-400",
  moderate: "bg-navy-300",
  low: "bg-sky-500",
};

export function LeakMap({ stages }: { stages: LifecycleStageResult[] }) {
  return (
    <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
      <Kicker>Retention leak map</Kicker>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">
        Where revenue is exposed across the customer lifecycle
      </h2>
      <p className="mt-3 max-w-2xl text-[0.92rem] leading-relaxed text-ink-soft">
        Each stage represents a point where a customer can either move toward renewal or quietly begin to leave.
        Narrower, darker segments indicate where retention revenue is most exposed.
      </p>

      <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {stages.map((stage, i) => {
          const leaking = stage.score < 55;
          const heightPct = Math.max(stage.score, 14);
          return (
            <div
              key={stage.id}
              className="animate-rise flex flex-col items-center"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="relative flex h-40 w-full items-end justify-center rounded-t-xl bg-navy-50/70 px-3 pt-3">
                <div
                  className={cn("w-8 rounded-t-md transition-all sm:w-10", RISK_BAR[stage.risk])}
                  style={{ height: `${heightPct}%` }}
                />
                {leaking && (
                  <Droplets
                    className="animate-drip absolute -bottom-1 right-3 h-4 w-4 text-alert-500"
                    strokeWidth={2}
                  />
                )}
              </div>
              <div className="w-full rounded-b-xl border border-t-0 border-line bg-white px-3 py-3 text-center">
                <p className="text-[0.78rem] font-semibold leading-snug text-navy-900">{stage.label}</p>
                <p className="mt-1 font-mono text-lg font-semibold text-navy-800">{stage.score}</p>
                <RiskBadge risk={stage.risk} className="mt-2" />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
