import { Target } from "lucide-react";
import type { DiagnosisResult } from "../../types/churn";
import { Card, DataTag, Kicker } from "../ui/primitives";

export function RootCause({ rootCause }: { rootCause: DiagnosisResult["rootCause"] }) {
  return (
    <section className="border-y border-line bg-navy-900">
      <div className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
        <Kicker tone="light">Root cause, not symptom</Kicker>
        <div className="mt-6 flex flex-col gap-6 sm:flex-row sm:items-start">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10">
            <Target className="h-5 w-5 text-sky-300" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-xl font-semibold leading-snug text-white sm:text-2xl">{rootCause.headline}</h2>
            <p className="mt-3 max-w-2xl text-[0.92rem] leading-relaxed text-white/70">{rootCause.explanation}</p>
            <DataTag source={rootCause.evidenceSource === "reported" ? "user" : "inference"} className="mt-4" />
          </div>
        </div>
      </div>
    </section>
  );
}

export function ActionPlan({
  priorityActions,
  plan30,
  plan90,
  whatToMeasureNext,
}: Pick<DiagnosisResult, "priorityActions" | "plan30" | "plan90" | "whatToMeasureNext">) {
  const columns = [
    { title: "Priority actions", items: priorityActions, tone: "text-alert-600" },
    { title: "30-day retention plan", items: plan30, tone: "text-sky-600" },
    { title: "90-day retention system", items: plan90, tone: "text-navy-600" },
    { title: "What to measure next", items: whatToMeasureNext, tone: "text-navy-400" },
  ];
  return (
    <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
      <Kicker>From diagnosis to execution</Kicker>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">The retention action plan</h2>
      <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-4">
        {columns.map((col) => (
          <Card key={col.title} className="flex flex-col">
            <p className={`font-mono text-[0.68rem] uppercase tracking-[0.14em] ${col.tone}`}>{col.title}</p>
            <ol className="mt-4 space-y-4">
              {col.items.map((item, i) => (
                <li key={i} className="flex gap-3 text-[0.83rem] leading-relaxed text-ink-soft">
                  <span className="mt-0.5 font-mono text-xs text-navy-200">{i + 1}</span>
                  <span>{item}</span>
                </li>
              ))}
            </ol>
          </Card>
        ))}
      </div>
    </section>
  );
}
