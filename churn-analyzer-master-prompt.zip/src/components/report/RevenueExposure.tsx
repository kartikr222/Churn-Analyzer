import { AlertCircle } from "lucide-react";
import type { RevenueImpact } from "../../types/churn";
import { Card, DataTag, Kicker, formatCurrency } from "../ui/primitives";

function Stat({
  label,
  value,
  source,
  suffix,
}: {
  label: string;
  value: string;
  source: "user" | "calculated" | "estimated" | "inference";
  suffix?: string;
}) {
  return (
    <div className="border-b border-line py-4 last:border-b-0 sm:border-b-0 sm:border-r sm:last:border-r-0">
      <div className="flex items-center justify-between gap-2 px-1">
        <p className="text-[0.78rem] text-ink-soft">{label}</p>
        <DataTag source={source} />
      </div>
      <p className="px-1 pt-2 font-mono text-2xl font-semibold text-navy-900">
        {value}
        {suffix && <span className="ml-1 text-sm font-normal text-navy-400">{suffix}</span>}
      </p>
    </div>
  );
}

export function RevenueExposure({ revenue }: { revenue: RevenueImpact }) {
  const s = revenue.currencySymbol;

  return (
    <section className="mx-auto max-w-6xl px-6 py-16 sm:px-8">
      <Kicker>Revenue impact engine</Kicker>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-navy-900 sm:text-3xl">Revenue exposure</h2>
      <p className="mt-3 max-w-2xl text-[0.92rem] leading-relaxed text-ink-soft">
        Every figure below is traceable: pulled directly from what you entered, calculated from it with a stated
        formula, or clearly marked as an estimate built on an assumption.
      </p>

      {!revenue.hasSufficientData ? (
        <Card className="mt-8 flex items-start gap-4 border-navy-100 bg-navy-50/50">
          <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-navy-400" strokeWidth={1.75} />
          <div>
            <p className="text-sm font-semibold text-navy-900">Insufficient financial data supplied</p>
            <p className="mt-1.5 text-[0.85rem] leading-relaxed text-ink-soft">
              To calculate revenue exposure, provide: {revenue.missingInputs.join(" and ")}. Every other section of
              this diagnosis remains valid — only the financial translation is currently unavailable.
            </p>
          </div>
        </Card>
      ) : (
        <>
          <Card className="mt-8 grid grid-cols-1 gap-4 p-6 sm:grid-cols-2 sm:gap-0 sm:p-0 lg:grid-cols-4">
            <div className="sm:p-6">
              <Stat label="Monthly recurring revenue" value={formatCurrency(revenue.mrr.value, s)} source={revenue.mrr.source} />
            </div>
            <div className="sm:p-6">
              <Stat
                label="Monthly revenue at risk"
                value={formatCurrency(revenue.monthlyRevenueAtRisk.value, s)}
                source={revenue.monthlyRevenueAtRisk.source}
              />
            </div>
            <div className="sm:p-6">
              <Stat
                label="Annualized revenue at risk"
                value={formatCurrency(revenue.annualizedRevenueAtRisk.value, s)}
                source={revenue.annualizedRevenueAtRisk.source}
              />
            </div>
            <div className="sm:p-6">
              <Stat
                label="Customers lost per month"
                value={revenue.customersLostMonthly.value !== null ? String(revenue.customersLostMonthly.value) : "—"}
                source={revenue.customersLostMonthly.source}
              />
            </div>
          </Card>

          {revenue.approximateLtv.value !== null && (
            <div className="mt-4 flex items-center gap-3 rounded-xl border border-line bg-white px-5 py-4">
              <p className="text-[0.85rem] text-ink-soft">Approximate customer lifetime value</p>
              <span className="font-mono text-lg font-semibold text-navy-900">
                {formatCurrency(revenue.approximateLtv.value, s)}
              </span>
              <DataTag source="estimated" />
              <span className="ml-auto hidden text-[0.72rem] text-navy-300 sm:inline">
                = avg. customer value ÷ monthly churn rate
              </span>
            </div>
          )}

          {revenue.scenarios.length > 0 && (
            <div className="mt-8">
              <p className="text-sm font-semibold text-navy-900">If churn improves, what's protected annually</p>
              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
                {revenue.scenarios.map((sc) => (
                  <Card key={sc.reductionPct} className="text-center">
                    <p className="font-mono text-xs uppercase tracking-wide text-navy-400">
                      {Math.round(sc.reductionPct * 100)}% churn reduction
                    </p>
                    <p className="mt-3 font-mono text-2xl font-semibold text-sky-600">
                      {formatCurrency(sc.annualRevenuePreserved, s)}
                    </p>
                    <p className="mt-1 text-[0.75rem] text-ink-soft">preserved annually</p>
                    <DataTag source="estimated" className="mt-3" />
                  </Card>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </section>
  );
}
