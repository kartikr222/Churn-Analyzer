import type { DiagnosisResult } from "../../types/churn";
import { HealthHero } from "./HealthHero";
import { LeakMap } from "./LeakMap";
import { RiskRanking, SideInsights } from "./RiskRanking";
import { RevenueExposure } from "./RevenueExposure";
import { RootCause, ActionPlan } from "./RootCause";
import { DiagnosticComposition, PriorityMatrix } from "./DiagnosticComposition";
import { Button } from "../ui/primitives";
import { RotateCcw } from "lucide-react";

export function ReportScreen({ diagnosis, onReset }: { diagnosis: DiagnosisResult; onReset: () => void }) {
  return (
    <div>
      <HealthHero overall={diagnosis.overall} confidenceNote={diagnosis.confidenceNote} />
      <LeakMap stages={diagnosis.lifecycle} />
      <RiskRanking topRisks={diagnosis.topRisks} />
      <SideInsights
        hiddenRisk={diagnosis.hiddenRisk}
        strongestAsset={diagnosis.strongestAsset}
        earlyWarningGap={diagnosis.earlyWarningGap}
      />
      <RevenueExposure revenue={diagnosis.revenue} />
      <RootCause rootCause={diagnosis.rootCause} />
      <PriorityMatrix dimensions={diagnosis.dimensions} />
      <ActionPlan
        priorityActions={diagnosis.priorityActions}
        plan30={diagnosis.plan30}
        plan90={diagnosis.plan90}
        whatToMeasureNext={diagnosis.whatToMeasureNext}
      />
      <DiagnosticComposition dimensions={diagnosis.dimensions} />

      <section className="mx-auto max-w-4xl px-6 pb-24 pt-4 text-center sm:px-8">
        <Button variant="ghost" onClick={onReset} className="mx-auto border border-line">
          <RotateCcw className="h-4 w-4" />
          Run a new diagnosis
        </Button>
      </section>
    </div>
  );
}
